package com.mobileservices.onlineapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "item")
public class ItemEntity {

	@Id
	@Column(name = "model")
	private int model;

	@Column(name = "itemname")
	private String itemname;

	@Column(name = "color")
	private  String color;

	@Column(name = "price")
	private float price;

	@Column(name = "features")
	private String features;

	@Column(name = "productid")
	private int productid;

	@Column(name = "categoryid")
	private int categoryid;

	@Column(name = "quantityavailable")
	private int quantityavailable;

	public ItemEntity() {
		super();
	}

	public ItemEntity(int model, String itemname, String color, float price, String features, int productid,
			int categoryid, int quantityavailable) {
		super();
		this.model = model;
		this.itemname = itemname;
		this.color = color;
		this.price = price;
		this.features = features;
		this.productid = productid;
		this.categoryid = categoryid;
		this.quantityavailable = quantityavailable;

	}
	
	public ItemEntity(int model) {
		super();
		this.model = model;
	}
	
	public ItemEntity(int model, String features, int quantityavailable) {
		super();
		this.model=model;
		this.features = features;
		this.quantityavailable = quantityavailable;

	}
	
	public ItemEntity(String features, int quantityavailable) {
		super();
		this.features = features;
		this.quantityavailable = quantityavailable;

	}


	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public int getQuantityavailable() {
		return quantityavailable;
	}

	public void setQuantityavailable(int quantityavailable) {
		this.quantityavailable = quantityavailable;
	}

}
