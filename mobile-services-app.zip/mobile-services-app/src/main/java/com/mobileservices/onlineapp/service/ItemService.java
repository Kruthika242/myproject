package com.mobileservices.onlineapp.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobileservices.onlineapp.entity.ItemEntity;
import com.mobileservices.onlineapp.repository.ItemRepository;

@Service
@Transactional
public class ItemService {
	
	@Autowired
	ItemRepository itemRepo;
	
	public List<ItemEntity> getAllItems() {
		return (List<ItemEntity>) itemRepo.findAll();
	}
	
	public ItemEntity getItemByModel(int model) {
		return itemRepo.findById(model).get();	
	}
	
	
	public void addProduct(int model, String itemname, String color, float price, String features, 
			int productid,int categoryid,int quantityavailable) {
		itemRepo.save(new ItemEntity(model,itemname,color,price,features,productid,categoryid,quantityavailable));
    }
	
	
	public void saveItem(ItemEntity item) {
        itemRepo.save(item);
    }
	
	public void deleteItem(int model) {
			itemRepo.deleteById(model);
    }

}
