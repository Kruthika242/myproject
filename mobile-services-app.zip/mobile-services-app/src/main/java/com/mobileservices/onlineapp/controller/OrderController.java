package com.mobileservices.onlineapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mobileservices.onlineapp.entity.ItemEntity;
import com.mobileservices.onlineapp.service.ItemService;
import org.springframework.ui.Model;

import com.mobileservices.onlineapp.service.OrderService;

@Controller
public class OrderController {

	@Autowired
	OrderService orderService;

	@Autowired
	ItemService itemService;

	@RequestMapping(value = { "/", "/adminlogin" })
	public String adminLogin() {
		return "adminlogin";
	}

	@RequestMapping("/logout")
	public String adminLogout() {
		return "logout";
	}

	// Show All Orders
	@RequestMapping("/orders")
	public String home(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Orders list.");
		model.addAttribute("orders", orderService.getAllOrders());
		return "orders";
	}

	@RequestMapping("/products")
	public String producthome(Model model) {
		System.out.println(this.getClass().getSimpleName() + ":=======>Showing Products list.");
		model.addAttribute("products", itemService.getAllItems());
		return "products";
	}

	@RequestMapping("/addproduct")
	public String add() {
		return "addproduct";
	}

	@RequestMapping(value = "delete/{model}", method = RequestMethod.GET)
	public String delete(@PathVariable("model") int model, Model mod) {
		System.out.println(model);
		itemService.deleteItem(model);
		mod.addAttribute("products", itemService.getAllItems());
		return "products";
	}

	@RequestMapping(value = "/saveitem", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("item") ItemEntity item, Model mod) {
		itemService.saveItem(item);
		mod.addAttribute("products", itemService.getAllItems());
		return "products";
	}

	@RequestMapping(value = "/update/{model}", method = RequestMethod.GET)
	public String updatePage(@PathVariable int model) {
		System.out.println(model);
		ModelAndView mod = new ModelAndView();
		ItemEntity item = itemService.getItemByModel(model);
		mod.addObject("edit", item);
		return "update";
	}
	
	@RequestMapping(value = "/savep", method={RequestMethod.GET,RequestMethod.POST})
	public String saveUpdate(@ModelAttribute("item") ItemEntity item, Model mod) {
		System.out.println("20");
		itemService.saveItem(item);
		System.out.println("20");
		mod.addAttribute("products", itemService.getAllItems());
		System.out.println("20");
		return "products";
	}


	
	/*  @RequestMapping("/update/{model}/{features}/{quantityavailable}") public ModelAndView
	  showEditProductPage( @PathVariable("model") int model,
	  
	  @PathVariable("features") String features,
	  
	  @PathVariable("quantityavailable") int quantityavailable) { 
	  ItemEntity item = new ItemEntity(model,features,quantityavailable);
	  itemService.saveItem(item);
	  ModelAndView mav = new ModelAndView("update"); 
	  mav.addObject("product",itemRepo.findAll()); 
	  return mav; 
	  }*/

	@GetMapping("/product/{model}")
	private ItemEntity getItems(@PathVariable("model") int model) {
		return itemService.getItemByModel(model);
	}

}
